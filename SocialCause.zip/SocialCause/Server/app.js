const express = require("express");
const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;
const session = require("express-session");
const ejs = require("ejs");
let data = {};
const app = express();
require("dotenv").config();
const cors = require("cors");
// Use CORS middleware
app.use(cors());
// Use sessio// Set the view engine to EJS n to keep track of login state
app.set("view engine", "ejs");

app.use(
  session({
    secret: "your-secret-key",
    resave: true,
    saveUninitialized: true,
  })
);
app.use(express.static("${process.env.CLIENT_URL}"));

// Initialize passport and session
app.use(passport.initialize());
app.use(passport.session());

// Set up Google OAuth2 strategy
passport.use(
  new GoogleStrategy(
    {
      clientID:
        "500065181427-3hlncbt7p8iokifhfj0d865q9p1nnf7j.apps.googleusercontent.com",
      clientSecret: "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",
      callbackURL: "http://localhost:3000/auth/google/callback", // Change this accordingly
    },
    (accessToken, refreshToken, profile, done) => {
      // Store user information in session
      return done(null, profile);
    }
  )
);

// Serialize user information into the session
passport.serializeUser((user, done) => {
  console.log("User", user);
  done(null, user);
});

// Deserialize user from the session
passport.deserializeUser((obj, done) => {
  console.log("obj", obj);
  done(null, obj);
});

// Middleware to check if the user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect("/login");
};

// Route for Google login
app.get(
  "/auth/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);

// Route for handling Google callback
app.get(
  "/auth/google/callback",
  passport.authenticate("google", { failureRedirect: "/login" }),
  (req, res) => {
    console.log("isAuth", req.isAuthenticated());
    data[req?.user._json.email] = {
      pageTitle: "EJS Example",
      message: "Hello from EJS!",
      email: req?.user._json.email,
      isAuthenticated: req.isAuthenticated(),
      displayName: req.user?.displayName,
    };

    res.redirect(
      `${process.env.CLIENT_URL}?auth=true&email=${req?.user._json.email}`
    );
  }
);

// Route to check if the user is authenticated
app.get("/", isAuthenticated, (req, res) => {
  console.log("process.env.CLIENT_URL", process.env.CLIENT_URL);
  res.redirect(process.env.CLIENT_URL);
});

// Route for logging out
app.get("/logout", (req, res) => {
  req.logout(function (err) {
    if (err) {
      return next(err);
    }
    // req.session.destroy();
    if (req.query?.email) delete data[req.query.email];

    res.redirect(`${process.env.CLIENT_URL}?auth=false`);
  });
  // res.redirect("/${process.env.CLIENT_URL}");
});

// Route for login page
app.get("/login", (req, res) => {
  // res.send('Please login with Google <a href="/auth/google">here</a>.');
  res.redirect(`${process.env.CLIENT_URL}`);
});
// app.get(`/public`, (req, res) => {
//   // console.log(req.isAuthenticated());
//   const data = {
//     pageTitle: "EJS Example",
//     message: "Hello from EJS!",
//     isAuthenticated: req.isAuthenticated(),
//     displayName: req.user?.displayName,
//   };

//   // Render the 'index.ejs' file and pass data to it
//   res.render("index", data);
// });
app.get(`/data`, (req, res) => {
  // console.log(req.isAuthenticated());
  // console.log(req);
  // Render the 'index.ejs' file and pass data to it
  // console.log("req.session", req.session.data);
  if (req.query?.email) return res.json(data[req.query?.email]);
  return res.json({
    pageTitle: "EJS Example",
    message: "Hello from EJS!",
    isAuthenticated: false,
    displayName: "",
  });
});
// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
