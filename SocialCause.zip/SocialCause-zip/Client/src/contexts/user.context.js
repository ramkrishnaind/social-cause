import { createContext, useState } from "react";
import { App, Credentials } from "realm-web";
import { APP_ID } from "../realm/constants";
// import red from '../../node_modules/@mui/material/colors/red';

// Creating a Realm App Instance
const app = new App(APP_ID);

// Creating a user context to manage and access all the user related functions
// across different components and pages.
export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [data, setData] = useState({
    pageTitle: "My App",
    message: "",
    email: "",
    isAuthenticated: false,
    displayName: "",
  });
  // Function to log in user into our App Service app using their email & password
  const emailPasswordLogin = async (email, password) => {
    const credentials = Credentials.emailPassword(email, password);

    const authenticatedUser = await app.logIn(credentials);
    setUser(authenticatedUser);
    return authenticatedUser;
  };
  const googleLogin = async () => {
    try {
      debugger;
      const redirectUrl = "http://localhost:5174/login";
      const credentials = Credentials.google({ redirectUrl });

      const authenticatedUser = await app.logIn(credentials);
      debugger;
      console.log("authenticatedUser", authenticatedUser);
      setUser(authenticatedUser);
      return authenticatedUser;
    } catch (error) {
      console.log("error", error);
      throw error;
    }
  };
  const confirmUser = async (token, tokenId) => {
    try {
      const data = await app.emailPasswordAuth.confirmUser(
        // {
        // details:
        { token, tokenId }
        //   }
      );

      console.log("data", data);
      // Since we are automatically confirming our users, we are going to log in
      // the user using the same credentials once the signup is complete.
      //   return emailPasswordLogin(email, password);
    } catch (error) {
      if (error.error === "invalid token data") {
        resendConfirmationEmail;
      }
      alert(error);
      throw error;
    }
  };
  const resendConfirmationEmail = async (email) => {
    try {
      const data = await app.emailPasswordAuth.resendConfirmationEmail(
        // {
        // details:
        email
        //   }
      );
      app.emailPasswordAuth;
      console.log("data", data);
      return { data: data };
      // Since we are automatically confirming our users, we are going to log in
      // the user using the same credentials once the signup is complete.
      //   return emailPasswordLogin(email, password);
    } catch (error) {
      if (error.error === "already confirmed") {
        return { data: "Already Confirmed" };
      }
      alert(error);
      throw error;
    }
  };
  // Function to sign up user into our App Service app using their email & password
  const emailPasswordSignup = async (email, password) => {
    try {
      await app.emailPasswordAuth.registerUser(
        // {
        // details:
        { email, password }
        //   }
      );

      //   app.emailPasswordAuth.confirmUser(token)
      // Since we are automatically confirming our users, we are going to log in
      // the user using the same credentials once the signup is complete.
      //   return emailPasswordLogin(email, password);
    } catch (error) {
      throw error;
    }
  };

  // Function to fetch the user (if the user is already logged in) from local storage
  const fetchUser = async () => {
    if (!app.currentUser) return false;
    try {
      await app.currentUser.refreshCustomData();
      // Now, if we have a user, we are setting it to our user context
      // so that we can use it in our app across different components.
      setUser(app.currentUser);
      return app.currentUser;
    } catch (error) {
      throw error;
    }
  };

  // Function to logout user from our App Services app
  const logOutUser = async () => {
    if (!app.currentUser) return false;
    try {
      await app.currentUser.logOut();
      // Setting the user to null once loggedOut.
      setUser(null);
      return true;
    } catch (error) {
      throw error;
    }
  };

  return (
    <UserContext.Provider
      value={{
        user,
        setUser,
        data,
        setData,
        fetchUser,
        confirmUser,
        resendConfirmationEmail,
        emailPasswordLogin,
        emailPasswordSignup,
        googleLogin,
        logOutUser,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};
