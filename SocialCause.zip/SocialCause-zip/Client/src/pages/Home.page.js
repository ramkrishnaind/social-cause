import { Button } from "@mui/material";
import { useContext, useEffect, useState } from "react";
import { UserContext } from "../contexts/user.context";
import { useSearchParams, useNavigate } from "react-router-dom";
import axios from "axios";

export default function Home() {
  let [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const email = searchParams.get("email");
  const handleLogout = () => {
    // Handle logout
    axios
      .get("http://localhost:3000/logout?email=" + email)
      .then((data) => {
        debugger;
        console.log("data", data);
        if (data?.data?.data.loggedOut) {
          setUser(null);
          setData({
            pageTitle: "My App",
            message: "",
            email: "",
            isAuthenticated: false,
            displayName: "",
          });
          navigate("/");
        }
        // setUser(null);
      })
      .catch((error) => console.error(error));
  };
  const { user, fetchUser, emailPasswordLogin, setUser, data, setData } =
    useContext(UserContext);
  debugger;
  //   const [user, setUser] = useState(user1);
  const { logOutUser } = useContext(UserContext);
  const loadUser = async () => {
    debugger;
    if (!user) {
      const fetchedUser = await fetchUser();
      if (fetchedUser) {
        // Redirecting them once fetched.
        setUser(user);
      }
    }
  };
  useEffect(() => {
    loadUser();
  }, []);

  // This function is called when the user clicks the "Logout" button.
  const logOut = async () => {
    try {
      // Calling the logOutUser function from the user context.
      const loggedOut = await logOutUser();
      // Now we will refresh the page, and the user will be logged out and
      // redirected to the login page because of the <PrivateRoute /> component.
      if (loggedOut) {
        window.location.reload(true);
      }
    } catch (error) {
      alert(error);
    }
  };

  return (
    <div style={{ width: "100vw", padding: "0 10vw" }}>
      {user?.isLoggedIn ? <h1>Welcome to {user?.profile?.email}</h1> : null}

      <Button variant="contained" onClick={logOut}>
        Logout
      </Button>
      {/* <div> */}
      <div>
        {data?.isAuthenticated && (
          <>
            Hello {data?.displayName}!
            <Button
              variant="text"
              sx={{ textTransform: "none" }}
              size="small"
              color="primary"
              onClick={handleLogout}
            >
              Logout
            </Button>
          </>
        )}

        {/* <a href="http://localhost:3000/logout">Logout</a> */}
      </div>
      {/* </div> */}
    </div>
  );
}
