// import React, { useState, useEffect } from "react";
// // import GoogleLoginButton from "./GoogleLoginButton"; // Assuming you have the GoogleLoginButton component
// import { useSearchParams } from "react-router-dom";
// import axios from "axios";

// const App = () => {
//   const [data, setData] = useState(null);
//   let [searchParams, setSearchParams] = useSearchParams();
//   const auth = searchParams.get("auth");
//   const email = searchParams.get("email");
//   useEffect(() => {
//     // Check if the user is already authenticated

//     axios
//       .get("http://localhost:3000/data?email=" + email)
//       .then((response) => {
//         debugger;
//         console.log(response);
//         setData(response.data);
//       })
//       .catch((error) => console.error(error));
//   }, [auth, email]);

//   const handleLoginSuccess = (profile) => {
//     // Handle successful login
//     debugger;
//     setData(profile);
//   };
//   console.log("data", data);
//   const handleLoginFailure = (e) => {
//     // Handle unsuccessful login
//     debugger;
//     console.log("Login failed");
//   };

//   const handleLogout = () => {
//     // Handle logout
//     axios
//       .get("http://localhost:3000/logout?email=" + email)
//       .then(() => setUser(null))
//       .catch((error) => console.error(error));
//   };

//   return (
//     // <GoogleLoginButton
//     //   onSuccess={handleLoginSuccess}
//     //   onFailure={handleLoginFailure}
//     // />
//     <div>
//       <h1>{data?.message}</h1>
//       {!data?.isAuthenticated ? (
//         <div>
//           Please login with Google{" "}
//           <a href="http://localhost:3000/auth/google">here</a>
//         </div>
//       ) : (
//         <div>
//           Hello {data?.displayName}!
//           <a href="http://localhost:3000/logout">Logout</a>
//         </div>
//       )}
//     </div>
//   );
// };

// export default App;
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { UserProvider } from "./contexts/user.context";
import Home from "./pages/Home.page";
import Login from "./pages/Login.page";
import PrivateRoute from "./pages/PrivateRoute.page";
import Signup from "./pages/Signup.page";
import ConfirmUser from "./pages/ConfirmUser";
function App() {
  return (
    <BrowserRouter>
      {/* We are wrapping our whole app with UserProvider so that */}
      {/* our user is accessible through out the app from any page*/}
      <UserProvider>
        <Routes>
          <Route exact path="/login" element={<Login />} />
          <Route exact path="/signup" element={<Signup />} />
          <Route exact path="/confirm-email" element={<ConfirmUser />} />
          {/* We are protecting our Home Page from unauthenticated */}
          {/* users by wrapping it with PrivateRoute here. */}
          <Route element={<PrivateRoute />}>
            <Route exact path="/" element={<Home />} />
          </Route>
        </Routes>
      </UserProvider>
    </BrowserRouter>
  );
}

export default App;
