export const APP_ID = "application-0-xfyxn";
